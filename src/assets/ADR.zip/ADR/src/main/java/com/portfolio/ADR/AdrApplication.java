package com.portfolio.ADR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdrApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdrApplication.class, args);
	}

}
