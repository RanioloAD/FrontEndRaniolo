package com.portfolio.ADR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdrApplicationTests {

	@Test
	void contextLoads() {
	}

}
